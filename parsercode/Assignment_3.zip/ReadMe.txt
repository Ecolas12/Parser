Emmanuel Colas
Project 3 Readme file

This is my project 3 the tiny PL/0 compilier. This program will take in code and turn it into assembly language that will print to a file and you terminal.
You need to compile this program by using command gcc parsercodegen.c in eustis.
Then to run use ./a.out [filename].txt. From there the program will print out the output to the terminal and to a file it will create called elf.txt. Commands in the source code are case sensitive. "Begin" will crash but begin will. Keywords must be lower case.